if (localStorage.getItem("username")) {
  window.location.assign(
    window.location.origin + "/@" + localStorage.getItem("username"),
  );
}

function invalidCharacterChecker() {
  let username = document.getElementById("username").value;
  let firstName = document.getElementById("first-name").value;
  let lastName = document.getElementById("last-name").value;
  let details = [username, firstName, lastName]; //creates an array with all the details taken from the sign up page
  let invalidCharacters = [
    "ㅤ",
    "⠀",
    " ",
    "@",
    "$",
    "%",
    "^",
    "&",
    "*",
    "(",
    ")",
    "/",
    "?",
    ";",
    ",",
    ".",
    "<",
    ">",
    "|",
    "`",
    "~",
    "[",
    "]",
    "{",
    "}",
    "=",
    "+",
    '"',
    "'",
  ]; //creates an array of invalid characters
  for (let i = 0; i < details.length; i++) {
    let detail = details[i];
    if (i > 0) {
      invalidCharacters.push(
        "1",
        "2",
        "3",
        "4",
        "5",
        "6",
        "7",
        "8",
        "9",
        "0",
        "#",
        "-",
        ":",
        "_",
        "!",
      );
    }
    for (let j = 0; j < invalidCharacters.length; j++) {
      let toCheck = invalidCharacters[j];
      for (let x = 0; x < detail.length; x++) {
        if (detail[x] == toCheck) {
          return true; //returns true if there is an invalid character
        }
      }
    }
  }
  return false;
}
function signUp() {
  let username = document.getElementById("username").value;
  let firstName = document.getElementById("first-name").value;
  let lastName = document.getElementById("last-name").value;
  let Class = document.getElementById("class").value;
  let section = document.getElementById("section").value;
  let house = document.getElementById("House").value;
  let gender = document.getElementById("Gender").value;
  let password = document.getElementById("password").value;
  let reconfirmPassword = document.getElementById("reconfirm-password").value;

  let ifInvalidCharacter = invalidCharacterChecker();
  if (!username || !password || !reconfirmPassword || !firstName || !lastName) {
    document.getElementById("error-text").innerText =
      "Please fill in all the fields";
  } else if (ifInvalidCharacter) {
    document.getElementById("error-text").innerText =
      "Do not use invalid characters";
  } else if (password != reconfirmPassword) {
    document.getElementById("error-text").innerText = "Passwords do not match";
  } else {
    // if all of the above requirements are met, the account is created
    console.log(localStorage.getItem("username"));

    let accountDetails = {
      username: username,
      firstName: firstName,
      lastName: lastName,
      class: Class,
      section: section,
      password: password,
      house: house,
      gender: gender,
    };

    // This statement, sends the details to the server
    $.post("/data/newAccount/check", accountDetails, (msg) => {
      if (msg == "Username already exists") {
        document.getElementById("error-text").innerText = msg;

        document.getElementById("username").value = "";
        document.getElementById("first-name").value = "";
        document.getElementById("last-name").value = "";
        document.getElementById("password").value = "";
        document.getElementById("reconfirm-password").value = "";
        document.getElementById("class").value = "";
        document.getElementById("section").value = "";
      } else {
        localStorage.setItem("username", username);
        document.getElementById("error-text").innerText = msg;
        window.location.assign(window.location.origin + "/@" + username);
      }
    });
  }
}
document.getElementById("log-in-button").addEventListener("click", () => {
  window.location.assign(window.location.origin + "/login");
});
