/* if (localStorage.getItem("username")) {
  window.location.assign(
    window.location.origin + "/@" + localStorage.getItem("username"),
  );
} */
let usernameInput = document.getElementById("username");
let passwordInput = document.getElementById("password");
let errorText = document.getElementById("messageBox");

$(document).ready(function () {
  document.getElementById("submit").addEventListener("click", function () {
    let pkg = {
      username: usernameInput.value,
      password: passwordInput.value,
    };

    $.post("/data/newLogin", pkg, function (msg) {
      if (msg == "Username or password is incorrect") {
        errorText.innerText = msg;
      } else {
        let splitArr = msg.split(";");
        let name = splitArr[0];
        let username = splitArr[1];

        messageBox.innerText = name;
        localStorage.setItem("username", username);
        console.log(localStorage.getItem("username"));
        window.location.assign(
          window.location.origin + "/@" + localStorage.getItem("username"),
        );
      }
    });
  });
  document
    .getElementById("sign-up-button")
    .addEventListener("click", function () {
      window.location.assign(window.location.origin + "/signup");
    });
});
