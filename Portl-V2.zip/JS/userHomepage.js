 // Gets the username of the user viewing the page
let user = localStorage.getItem("username");
let pfp = document.getElementById("pfp").src;
// URL of the page
let url = window.location.href
// Gets all the elements with the class editor-mode amd puts it in an array
let editorElements = document.getElementsByClassName("editor-mode"); 
for(let i=0; i<editorElements.length; i++){ //loops through the array
  editorElements[i].style.display = "none"; //sets them to be hidden and noninteractive
}
function imageToBase64(element) {
  let file = element.files[0];
  let reader = new FileReader();
  reader.onloadend = function() {
    pfp = reader.result
    console.log(reader.result)
  }
  reader.readAsDataURL(file);
}
function userChecker(){

  // Splits the url to get the username
  let username = url.split("@")[1]
  console.log(username)

  // Check if the user exists
  $.post(`/data/portDetails/${username}`, function(d){

     // If the user exists: fill the page with the details
    if(d == "Go"){

      // Calls the function to fill the page with the details
      userHomepageFill();
      
      //checks if the viewer and the owner are the same
      if(username == user){
        // Allows the user to edit
        document.getElementById("editor").style.display = "inline";
      }
      else if(username != user){
         // Doesn't allow the user to edit
        document.getElementById("editor").style.display = "none";
      }

    // If it doesn't exist: Page doesn't exist
    } else if(d == "No go"){
      document.getElementById("portfolio").innerHTML = "Sorry, this page doesn't exist"
    }
  })
}
function userHomepageFill(){ //fills the page with data

  // Hide the edit button, show the save button
  document.getElementById('save').style.display = "none";

  // Puts the username of the owner of the port into an object
  let pkg = { 
    username: url.split("@")[1]
  }
  
  // Sends the object and gets the data from the database
  $.post('/data/userDetails', pkg, function(d){
    
    // Data from the database is in an array, this accesses the 0th element 
    let data = d[0]

    //displays the data from the database onto the page
    document.getElementById("pfp").src = data.profilePicture; 
    console.log(data.profilePicture)
    document.getElementById('full-name').innerText = data.firstName + " " + data.lastName;
    document.getElementById('username').innerText = "@" + data.username;
    document.getElementById('class').innerText = data.class;
    document.getElementById('section').innerText = data.section;
    document.getElementById('gender').innerText = data.gender;
    document.getElementById('house').innerText = data.house; 
    document.getElementById('career').innerText = data.career;
    document.getElementById('description').innerText = data.description;
    document.getElementById('achievements').innerText = data.achievements;
    document.getElementById('skills').innerText = data.skills;
    document.getElementById('creations').innerText = data.creations
  })
  /* for(let i = 1; i<images; i++){
    document.createElement(img).src = images[i];
  } */
}
function toEditor(){ //puts you in editor mode

  // Show the buttons
  document.getElementById('save').style.display = "inline"
  document.getElementById('editor').style.display = "none"  
  
  //gives the data from the page to all the editable data's input fields
  document.getElementById('career-edit').value = document.getElementById('career').innerText
  document.getElementById('description-edit').value = document.getElementById('description').innerText
  document.getElementById('skills-edit').value = document.getElementById('skills').innerText
  document.getElementById('achievements-edit').value = document.getElementById('achievements').innerText
  document.getElementById('creations-edit').value = document.getElementById('creations').innerText

  //checks if the user is in grade 11 or 12
  if(document.getElementById('class') == "11" || document.getElementById('class') == "12"){
    document.getElementById('stream-edit') = document.getElementById('stream').innerText 
    //sets the stream value to the stream input field
  }
  document.getElementById('editor').style.display = "none";
  document.getElementById('save').style.display = "inline";
  let elements = document.getElementsByClassName('editor-mode'); //get array of editor elements
  for(let i = 0; i < elements.length; i++){
    elements[i].style.display = "inline"; //sets all elements of the array to visible
  }

  let viewElements = document.getElementsByClassName('viewer-mode')
  for(let i=0; i<viewElements.length; i++){
    viewElements[i].style.display = "none"
  }
}
function Save(){ //saves the new, edited data


  //gets all the data from the input fields
  let description = document.getElementById('description-edit').value;
  let career = document.getElementById('career-edit').value;
  let achievements = document.getElementById('achievements-edit').value;
  let skills = document.getElementById('skills-edit').value;
  let creations = document.getElementById('creations-edit').value;

  if(!pfp){
    newData = {
      username: user,
      description: description,
      career: career,
      achievements: achievements,
      skills: skills,
      creations: creations,
      profilePicture: "noPfp"
    }
  }
  else{
    document.getElementById("pfp").src = pfp
    console.log("SETTING NEW PFP")
    newData = {
      username: user,
      description: description,
      career: career,
      achievements: achievements,
      skills: skills,
      creations: creations,
      profilePicture: pfp
    }
  }
  //creates an object with the new data

  
  //sends the new data to the server
  $.post("/data/savePort", newData)
  userHomepageFill()
  //switches back to view mode
  document.getElementById('save').style.display = "none"
  document.getElementById('editor').style.visibility = "visisble";
  let elements = document.getElementsByClassName('editor-mode');
  for(let i = 0; i < elements.length; i++){
    elements[i].style.display = "none";
  }

  //for loop for viewer elemenets
  let viewerElements = document.getElementsByClassName('viewer-mode');
  for(let i = 0; i < viewerElements.length; i++){
    viewerElements[i].style.display = "inline";
  }
}
function Cancel(){
  userHomepageFill() //fills the homepage with the default data
  // for loop for editor elements  
  let editorElements = document.getElementsByClassName('editor-mode');
  for(let i = 0; i < editorElements.length; i++){
    editorElements[i].style.display = "none";
  }
  //for loop for viewer elemenets
  let viewerElements = document.getElementsByClassName('viewer-mode');
  for(let i = 0; i < viewerElements.length; i++){
    viewerElements[i].style.display = "inline";
  }
}
function toSettings(){ //for the button that takes you to the settings page
  window.location.assign(window.location.origin + "/settings")
}
function toHub(){ //for the hub button
  window.location.assign(window.location.origin + "/hub")
}
document.getElementById("portl-logo").addEventListener("click", () => {
 window.location.assign(window.location.origin); 
})
userChecker(); //calls the function to check the user

