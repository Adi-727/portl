localStorage.getItem("username");
if (!username) {
  window.location.assign(window.location.origin);
}
document.getElementById("log-out").style.display = "none";
function LogOut() {
  document.getElementById("log-out").style.display = "visible";
  document.getElementById("no-go-back").addEventListener("click", () => {
    document.getElementById("log-out").style.display = "none";
  });
  document.getElementById("yes").addEventListener("click", () => {
    localStorage.removeItem("username");
    window.location.assign(window.location.origin);
  });
}
