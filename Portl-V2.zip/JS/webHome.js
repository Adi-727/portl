const user = localStorage.getItem("username");

if (!user) {
  document.getElementById("login-button").style.visibility = "visible";
  document.getElementById("sign-up-button").style.visibility = "visible";
} else {
  document.getElementById("login-button").style.visibility = "hidden";
  document.getElementById("sign-up-button").style.visibility = "hidden";
}
function toLogIn() {
  window.location.assign(window.location.origin + "/login");
}
function toSignUp() {
  window.location.assign(window.location.origin + "/signup");
}
function CreateNow() {
  if (user) {
    window.location.assign(
      window.location.origin + "/@" + localStorage.getItem("username"),
    );
  } else {
    window.location.assign(window.location.origin + "/login");
  }
}
function addAction() {
  let word = "Portfolio made simple";
  let line = document.getElementById("cta-text");
  let line2 = document.getElementById("cta-catch");

  let timeout = 0;
  for (let i = 0; i < word.length; i++) {
    timeout += 250 * Math.random();

    if (i >= 14) {
      timeout += 100;
      setTimeout(function () {
        line2.innerHTML += word[i];
      }, timeout);
    } else {
      setTimeout(function () {
        line.innerHTML += word[i];
      }, timeout);
    }
  }
}
document.getElementById("portl-logo").addEventListener("click", () => {
  window.location.assign(window.location.origin);
});
