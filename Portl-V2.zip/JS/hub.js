//checks if the user is logged in and if not removes the my portfolio button
let user = localStorage.getItem("username");
if (!user) {
  document.getElementById("my-portfolio-button").style.display = "none";
}

// A function to load portfolios into the page
function loadPorts(ports) {
  const portsContainer = document.getElementById("ports"); // Get the container element
  portsContainer.innerHTML = ""; // Clear previous content
  // For loop for appending each detail into each div
  ports.forEach((port) => {
    // Create elements
    const portDiv = document.createElement("div");
    const usernameSpan = document.createElement("span");
    const nameSpan = document.createElement("span");
    const classNSectionSpan = document.createElement("span");

    // Set content
    usernameSpan.className = "usernameSpan";
    usernameSpan.textContent = `@${port.username}`;
    nameSpan.className = "nameSpan";
    nameSpan.textContent = `${port.firstName} ${port.lastName}`;
    classNSectionSpan.className = "classNSectionSpan";
    classNSectionSpan.textContent = `${port.class}${port.section}`;

    // Append elements
    portDiv.appendChild(nameSpan);
    portDiv.innerHTML += "<br>";
    portDiv.appendChild(usernameSpan);
    portDiv.innerHTML += "<br>";
    portDiv.appendChild(classNSectionSpan);
    portDiv.innerHTML += "<br>";
    portDiv.className = "portDiv";
    portDiv.id = "portDiv_" + ports.indexOf(port); // Use indexOf for unique IDs
    // Append to container
    portsContainer.appendChild(portDiv);
    portsContainer.innerHTML += "<br>";


    
  });

  // Get all the ports after appending them
  let thePortDivs = document.getElementsByClassName("portDiv");
  
  for(let i = 0; i < thePortDivs.length; i++){
    // What to do if one is clicked
    function toPort(){
      console.log(thePortDivs[i].childNodes[2].textContent)
      window.location.assign(window.location.origin + '/' + thePortDivs[i].childNodes[2].textContent)
    }
    
    thePortDivs[i].addEventListener("click", toPort)
  }
  
}



// Checking if user has logged in
let usernameView = document.getElementById("username-view");
usernameView.addEventListener("click", () => {
  //makes the username a button to the accountSettings page
  window.location.assign(window.location.origin + "/accountSettings");
});
if (user) {
  usernameView.textContent = user;
}

// Search function
function search() {
  // Variables
  let searchInput = document.getElementById("search-bar").value;
  let resultPorts = [];

  $.post("/data/hub/ports", (ports) => {
    console.log(ports);

    // Check for the searched thing in the portfolio
    for (let i = 0; i < ports.length; i++) {
      // Username
      if (
        ports[i].username
          .toLowerCase()
          .split(" ")
          .includes(searchInput.toLowerCase())
      ) {
        if (resultPorts.includes(ports[i]) == false) {
          resultPorts.push(ports[i]);
        }
      }
      // First name
      if (
        ports[i].firstName
          .toLowerCase()
          .split(" ")
          .includes(searchInput.toLowerCase())
      ) {
        if (resultPorts.includes(ports[i]) == false) {
          resultPorts.push(ports[i]);
        }
      }
      // Last name
      if (
        ports[i].lastName
          .toLowerCase()
          .split(" ")
          .includes(searchInput.toLowerCase())
      ) {
        if (resultPorts.includes(ports[i]) == false) {
          resultPorts.push(ports[i]);
        }
      }
      // Skills
      if (
        ports[i].skills
          .toLowerCase()
          .split(" ")
          .includes(searchInput.toLowerCase())
      ) {
        if (resultPorts.includes(ports[i]) == false) {
          resultPorts.push(ports[i]);
        }
      }
      // Achievements
      if (
        ports[i].achievements
          .toLowerCase()
          .split(" ")
          .includes(searchInput.toLowerCase())
      ) {
        if (resultPorts.includes(ports[i]) == false) {
          resultPorts.push(ports[i]);
        }
      }
      // Description
      if (
        ports[i].description
          .toLowerCase()
          .split(" ")
          .includes(searchInput.toLowerCase())
      ) {
        if (resultPorts.includes(ports[i]) == false) {
          resultPorts.push(ports[i]);
        }
      }
    }

    // Load the resulted ports
    loadPorts(resultPorts);
  });
}

// Anything involving data from the server is inside this
$(document).ready(() => {
  // Get ports
  $.post("/data/hub/ports", (portfolios) => {
    loadPorts(portfolios);
  });
});

//makes to portfolio button work
document.getElementById("my-portfolio-button").addEventListener("click", () => {
  window.location.assign(
    window.location.origin + "/@" + localStorage.getItem("username"),
  );
});
document.getElementById("portl-logo").addEventListener("click", () => {
  window.location.assign(window.location.origin);
});
function toSettings(){
  window.location.assign(window.location.assign + "/settings");
}