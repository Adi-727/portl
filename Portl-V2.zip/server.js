// Welcome to... The Homebase

// Required variables

const express = require("express");
const app = express();
const port = 3000;
const path = require("path");
const sqlite = require("sqlite3");
const bodyParser = require("body-parser");

// import userHomepageFill from './JS/userHomepage.js';
// const LoggedIn = require('./logIn.js');

app.use(bodyParser.urlencoded({ extended: false }));
const db = new sqlite.Database("./database/database.db");

// Prerequisites (You can call it that)
db.serialize(function () {
  db.all("SELECT * FROM ports", function (e, d) {
    if (e) {
      console.log(e);
    } else {
      console.log(d);
    }
  });

  db.all("SELECT * FROM sqlite_master WHERE type='table'", (error, data) => {
    if (error) {
      console.log(error);
    } else {
      console.log(data);
      console.log("-----------------------------------------------------");
    }
  });
});

// ------------------ Data --------------------------

// Database testing
app.post("/dbtest", (req, res) => {
  db.all("SELECT * FROM test", (err, data) => {
    if (err) {
      console.log(e);
    } else {
      res.send(data);
    }
  });
});

// Sending user details for their respective userHomepages
app.post("/data/userDetails", function (req, res) {
  let pkg = req.body;

  db.all(
    "SELECT * FROM ports WHERE username=$username",
    {
      $username: pkg.username,
    },
    function (error, data) {
      if (error) {
        console.log(error);
      } else {
        console.log(data)
        res.send(data);
      }
    },
  );
});

// Saving a port
app.post("/data/savePort", function (req, res) {
  let details = req.body;

  console.log(details);

  if(details.profilePicture == "noPfp"){
    db.run(
      "UPDATE ports SET description=$description, career=$career, achievements=$achievements, skills=$skills, creations=$creations, saved='yes' WHERE username=$username",
      {
        $description: details.description,
        $career: details.career,
        $achievements: details.achievements,
        $skills: details.skills,
        $creations: details.creations,
        $username: details.username
      },
      function (e) {
        if (e) {
          console.log(e);
        }
      },
    );
  }

  else {
    db.run(
      "UPDATE ports SET description=$description, career=$career, achievements=$achievements, skills=$skills, creations=$creations, profilePicture=$pfp, saved='yes' WHERE username=$username",
      {
        $description: details.description,
        $career: details.career,
        $achievements: details.achievements,
        $skills: details.skills,
        $creations: details.creations,
        $username: details.username,
        $pfp: details.profilePicture
      },
      function (e) {
        if (e) {
          console.log(e);
        }
      },
    );
  }
  
});

// Sending the ports to the hub
app.post("/data/hub/ports", (req, res) => {
  db.all(
    "SELECT username, firstName, lastName, class, section, description, skills, achievements, saved FROM ports",
    (e, d) => {
      if (e) {
        console.log(e);
      } else {
        let arr = [];

        for (let i = 0; i < d.length; i++) {
          if (d[i].saved == "yes") {
            arr.push(d[i]);
          }
        }

        res.send(arr);
      }
    },
  );
});

// Signing up
app.post("/data/newAccount/check", (req, res) => {
  let account = req.body;

  // Check if username already exists
  db.all("SELECT username FROM ports", (e, d) => {
    if (e) {
      console.log(e);
    } else {
      let x = d.length;
      let y = 0;

      for (let i = 0; i < d.length; i++) {
        if (d[i].username == account.username) {
          res.send("Username already exists");
        } else {
          y++;
        }
      }

      if (x == y) {
        db.run(
          "INSERT INTO ports (username, password, firstName, lastName, class, section, house, gender, profilePicture) VALUES ($username, $password, $firstName, $lastName, $class, $section, $house, $gender, $pfp)",
          {
            $username: account.username,
            $password: account.password,
            $firstName: account.firstName,
            $lastName: account.lastName,
            $class: account.class,
            $section: account.section,
            $house: account.house,
            $gender: account.gender,
            $pfp: "data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/4gHYSUNDX1BST0ZJTEUAAQEAAAHIAAAAAAQwAABtbnRyUkdCIFhZWiAH4AABAAEAAAAAAABhY3NwAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQAA9tYAAQAAAADTLQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAlkZXNjAAAA8AAAACRyWFlaAAABFAAAABRnWFlaAAABKAAAABRiWFlaAAABPAAAABR3dHB0AAABUAAAABRyVFJDAAABZAAAAChnVFJDAAABZAAAAChiVFJDAAABZAAAAChjcHJ0AAABjAAAADxtbHVjAAAAAAAAAAEAAAAMZW5VUwAAAAgAAAAcAHMAUgBHAEJYWVogAAAAAAAAb6IAADj1AAADkFhZWiAAAAAAAABimQAAt4UAABjaWFlaIAAAAAAAACSgAAAPhAAAts9YWVogAAAAAAAA9tYAAQAAAADTLXBhcmEAAAAAAAQAAAACZmYAAPKnAAANWQAAE9AAAApbAAAAAAAAAABtbHVjAAAAAAAAAAEAAAAMZW5VUwAAACAAAAAcAEcAbwBvAGcAbABlACAASQBuAGMALgAgADIAMAAxADb/2wBDAAMCAgICAgMCAgIDAwMDBAYEBAQEBAgGBgUGCQgKCgkICQkKDA8MCgsOCwkJDRENDg8QEBEQCgwSExIQEw8QEBD/2wBDAQMDAwQDBAgEBAgQCwkLEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBD/wAARCAI0AjQDASIAAhEBAxEB/8QAHAABAQACAwEBAAAAAAAAAAAAAAIBBwMFBgQI/8QAOhABAAEDAgEKBAQEBgMAAAAAAAIDBBIFBnEBBxMUIjJCUmFyFjFVYhEjMzUVNHOSISRBQ0SCUYGi/8QAGAEBAQEBAQAAAAAAAAAAAAAAAAIDAQT/xAAaEQEBAQEBAQEAAAAAAAAAAAAAAhIBExEx/9oADAMBAAIRAxEAPwD9lgPQyAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABy0bWtdSwoQyk9doOw615jO9ypA8jRoVqssIQl/Y7yx2Vqt/jOlj/ANmz9M21YadTw6GnU90HZ06FGl3KMYs9qy13Z829zH+ahH+921Hm803/AHaL2YnRl5aPN5t7xW0lS5v9veG2k9OJ0t46tzeaV/tW7rbvm3lL+WjDkbAzM1a6NQ32wNYtcp9nF5+6sLm1lhVhJv2VOE+/CMnw32iafeU5QlbUo5eLFW0ZaLS2DrnN5COVa1nKcvLGLw95pt5YVJQr0ZRXtL5gHQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAfbpul3OqXEaNvBx6fZTv7inRjDvzbd21tujpFvHKH41Pui5VZJfNtvZ1tYU41rqjCdTvRepjGMY4xUMGoAAAAAAAAAA6TXNtWWrUJfjR/O8MndgNIa9t650itLOHZz8Lpm9NY0i21O3lTnCOXtai3FodbRryVHCeLWaZVLqAFgAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAzGM5ywiw9Ds3Rv4jqVPpYflg9ZsXbULen1y6hGUp9qD3bhtqELejGjH5RczztQAAAAAAAAAAAAAB5zdugw1SyqThTj03mejAfn68tZ2VxUoy8M3A93zhaF0FSndW8O/2pvCN4ZADoAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAzTjnKMINsbC0nqumxrTh+Zk1rodrO61Cj5c28bS3hbUY06fyZ31UvoAZrAAAAAAAAAAAAAAAAdTuHTqd/p9XklHtRi0ldUJ2taVGbf9SHS05Ql4mot+WHVdYqThDs4tIRTzADRIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAD1vN/ZdavKk/K21Hu8jwfNrZdX6at54vesqVIAhYAAAAAAAAAAAAAAACIf6PB85Fl/l5XmD3kP9Hnt82vWtFlD7lT+jTYutHCpKHkQ2ZAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAANw7HodFp9Ofmi9O6TacMNHt/a7t52oAAAAAAAAAAAAAAAAAA67XaXS2MoOxfPexyt5chwaG1CGF9Wh97gfXq37lcf1ZvkejjIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABvPbUfw0Oz/pO1dNtWeWi2vsdy87UAAAAAAAAAAAAAAAAAAcVaOVGXtcrguZYUZe04NE6z+63X9Wb5H16t+63X9Wb5Ho4yAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAbl2ZcdLplGHlg9G8NzcXvWKdSj5IvcvPTUAAAAAAAAAAAAAAAAAAfBrFXoLOU33ug3nddV0eVT7jg0/qU8764n975l3E8q1Sfnkh6OMgAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAHsebu/6leVoSn3212hNHup2t9RnCfibxsLqF5bxrQ7rKlS+oBCwAAAAAAAAAAAAAAAB4TnIv4dRlZ5drJ7erPkp05VJeFqDfGo9c1iphPs4KlFPNANkgAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAMxnjLODaHN9rPS2kbCrP8zJq52+2dU/hepU62fZcslvEfLY3ULy1p1oS78X1MGoAAAAAAAAAAAAAACZSjGOUgdHuvVoadp8ocsu1Vi0xWqzr1M5d56zfmt9fuo21Kf6U3kGssqAFgAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAADYOxd0Yy6ndT+2DYj8/2tedrWjWj4G2Nn7oo6laxo160em8rO5XNPVgM1AAAAAAAAAAAADyW89xw063qW1Cf5ztte1u20u1ly1a0Yyn3WndY1Stql1KtVVMop8dxVnXrSrT700A2SAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAPpsb+5sK0a1CeMnzANu7V3ZR1KjGjVn+ZHs9p6nklyS7rQFneVrOtGtSnPsNhbb39Tnyxt9RlClyMalU09+OC1vKF5DpLeeUXOlYAAAAAADjq1YUo51OX8Ig5HTbg3BbaRbynKfadVuDe1nYU5UrOtCdTytaatrNzq1x01Wf8A9KmUac2ua5c6tcSnOtLo8uzF1QNkgAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAADMZ4y7DADu9J3RqWnSj/AJmUqfle40jnDtrvGjVoyjLzSasU5g03va6zYXUc4XNL+59UbijPuVotB295WoSzhOTtrfeGq2/cnFGFabqyj/5MuRqGPOHrcO50RLnG16f+lJzJptqVejHvzi4K2qWFKPbuqX9zUVbeusV+9i6u61S5uv1Zu4NNpatvuz0+MsIdL7Xh9Y3pf38pdXrVaUfK83lOXjYXhOl1qta4lnVnlJAOgAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAC6dvWqywjCf8AYCB3+m7N1XUcZ0sY+56bT+biUMeuxhJzZlruMJz7r6I2F5V7lGUm2rXYeg0I9q27TsaG3dLofp0Pw/8AaNqy01HRNVl3bOqqO3tYn/wKrd1OwtqXcg5o0oR7p6mWi/hzW/ptVn4c1v6bVb2D1MtE/Dmt/Tap8Oa39Nqt7B6mWifhzW/ptU+HNb+m1W9g9TLRPw5rf02qfDmt/Tareweplon4c1v6bVPhzW/ptVvYPUy0T8Oa39Nqnw5rf02q3sHqZaJ+HNb+m1T4c1v6bVb2D1MtEfD2t/T6qZaDqsP+HVb2lGE3HKzoz70D1MtDy0u/pd+2nFw1KU6Xfg3pW0HTa/6lF8FxsnQbjk/CdsbMtLjZt9zdUJfydGEXmdS2HqtnlPs4/avacvMDnuLO5t5YToy/tcTokAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAGYxnPuQyBhz2thc3ssLWjKUnfbf2beapKM+7H7mx9I2xp+m04/wCWh0nJ4kVRl4bRdg3N1jO/hVpPdaXtew06MexGp7ou45OyZ+qO01yinQo0eT8ulCPti5gSAAAAAAAAAAAAAAAAAAAAAADjlThPvwjJyAOsvtCsb6nywnQp8nri8brXN5CGVaynKcvK2FmK5XRoe+0a/wBOlLrVtOL4m9tS0Sw1SnKNxRy5WvtxbDubWUq1rj0fliuaZZeKF1KValLCrCUULAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAHPZ2da8rRo0oT7YJtbWtdVuht4ZSbA2vsOHZub+EoS70HabV2bR0+nGvdwjKo9XGPJHkwj8mdWqZRRtaNCOFKEY/8AVzgzWAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAOOpShVjjOEZOQB5Dc2y7bUoyuaEPzPLGDWeqaXc6XWlC4hi326HX9t2uq0Zfkx6TzKmkZaVHY61olzpFxKjV7UfM65skAAAAAAAAAAAAAAAAAAAAAAAAAAAABmnHOUYQByWtrWuq0aNCGUptqbQ2rDT6MbqtD8ycXW7F2vhGN/dQ7UJd2T3sY8keTCPyZ3SplyAM1gAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAOj3Jt+jq9rKGHaai1bS7nS7iVGrDGOfZb5eY3dtyjqVrKtShHKEVTSKn608OW6tZ2taVGrDGTibJAAAAAAAAAAAAAAAAAAAAAAAAAAHqdl7e/iV1nVh2Ydt5/T7Kd/dU7aPjbk27pcNN0+jDD8zDtoqiXaUaUKVOMIuRC82TVYgzBbGXI48uBlwByZchlyOPLgZcAVmJy4KzBYjMzBWXIS+ScwA8AArLkMuRJmCsuQy5HHlwUCsuRlAAGaAWIAX4FozAWIzTlwBysZcjjy4GXAHJlyGXI48uBlwBS0ZmYLYy5E5mYKl8kgB4CXajgANe7+25+MZalSh2pNeyhhLBvy+tYXtvKjVhGTTO5NJnpd9LLuznObWaRTqAFpAAAAAAAAAAAAAAAAAAAAAAActrSnVuKcIecHtOb/RusVI6lOH6UmyXUbfsIWFjGEPFGE3bsqVLGXoZejAhahIChIChIChKgBjL0YBQkBeXAy4IAUJAUzlwYBDOXAy4IBahKgYy9DL0MvRgGcvQy9GAFCQFCQFCQFAxKYMiQFM5cEALy4MJAU8hvzRuu28rzDtUoPWuC+oQurWpRn41yhoeUMGHa7ksOpapWo4dmDqmqQAAAAAAAAAAAAAAAAAAAAAB6PZendf1LCcO523nGx+b+w6KMbnDvwcse2p9mnGHkgCcuDNSjNOXAy4AoEAsQzlwBQZseIGTNCvEDIZpy4AoTlwUACcuAKE5cGEDmQhawW4suCgVmygAE5cDLgCsxOXBQAgBYnLgrMAQAvMQvMATlwMuAKAA8YnLgZcAUtwiB4LnC0voo9cjDtTm8E2/u6z67p+GHcajrRwqSh9zeE0gB0AAAAAAAAAAAAAAAAAAAAXThlUjBtzadKFDRbfzNU6XHpb6nD7m4NHj0Wn04Iol2GXoZejAlShGWDIKEgKEZmYLEZmYKy9DL0YZy9AIkU5mYLYkwAzI8LACmMvRhjMFZejKMzMFiQGcvQy9GAGcvQy9GGMsAV4WUZsgoSxmCxGZmC2MvROZmCsvQiwzl6ARZRmyDMiTADPhZSAzl6GXonMzBN5CFW1qZ+WbSepUugvKkPvm3ZW7dOXsaj3VQ6vqCpS6YBYAAAAAAAAAAAAAAAAAAAA7Hb8c9Wt/c3Bb9mjFqHbfb1q197cFPsxRQoM0y+aVKEy+bALEALE5cGAWCcuAKE5cGAWIZ9oKEM5cAUJy4GXAFCcuBlwBRmgBeas3EA5c0pj81ZgCZfMl8wUIAWIAWIWAJy4GXAFCGfaChPtYBYnLgZcAUJy4GXAFCcuDALl3Gsd+Rw1Kn7Gy2uOcKOGqUfaqR5QBaQAAAAAAAAAAAAAAAAAAAHZ7Y/erX3tvtQbb/erX3tuooUJYzSpbGXonNkFCQFMZejDGYLEp8QLy9DL0YT4gcgkBTGXonNkFMeJgBmJ4k5sgpjL0ZSChIChIChGZmCsvRlIChIDOXoyjNkFMZejADOXoykBQljMFZehl6MAM+JlLGYK8TKM1gxl6Nd84v7pR9rYbXfOL+5UfYqR5MBaQAAAAAAAAAAAAAAAAAAAHZ7b/AHq197bWbUOgzw1a3n97bVGrlTjNFDkEApYmPzMuAKE5cDLgCjNOXAy4AoTlwYBacuDACxACyUk5cGEi5SEChZmgSLzEChYnLgZcEisxOXBgFiGY/NQoTlwMuCRQnLgZcAVmJy4GXBQoQAvMQAsQzlwBUpGaAFiAF5maBItr3nC/cqPsbAlPstc74q9LqFP2KlLzQCwAAAAAAAAAAAAAAAAAAABz2NXq91Tn5G1NDuOn0+nNqR7nZuqZxjZzn3IuUPYZejKWJfJKliM2QUJAUxl6JzMwWJAGfEnNkFMSYAUIzMwWJAZy9GUZsgKSApjL0cawZy9DL0TH5MgoRL5GYLYy9GAFCWMwVl6MozZBSRjMFsSYAZkyljMFZejKM2QUxl6MMZgtIAitLGjUn9jVuvXXWryU/I95uTUuoWfYn3+w1nWnnUlPzzVCUAOgAAAAAAAAAAAAAAAAAAAA7nbP88ANlUv0o+xQIUAAAAeBYAnwsAAACo/Ij8gA5fnJIAAAAAAAAAAAAAAAHgAGfCeEAYAAVH5ABH5MeIAYAAAAAB4fek5ZS/x8byQLSAAAAAAAAAAAA//Z",
          },
          (er) => {
            if (er) {
              console.log(er);
            } else {
              res.send("Account created");
            }
          },
        );
      }
    }
  });
});

// Logging in
app.post("/data/newLogin", function (req, res) {
  let account = req.body;
  console.log(account);

  db.all(
    "SELECT username, password, firstName, lastName FROM ports",
    function (e, d) {
      if (e) {
        console.log(e);
      } else {
        let x = d.length;
        let y = 0;

        for (let i = 0; i < d.length; i++) {
          if (
            d[i].username == account.username &&
            d[i].password == account.password
          ) {
            res.send(
              `Welcome ${d[i].firstName} ${d[i].lastName};${d[i].username}`,
            );
          } else {
            y++;
          }
        }

        if (x == y) {
          res.send("Username or password is incorrect");
        }
      }
    },
  );
});

// Viewing other people's portfolios

// ------------------ GET & POST requests ----------------------

// The header.css file
app.get("/CSS/universal-header", (req, res) => {
  res.sendFile(path.join(__dirname, "CSS/header.css"));
});

// The main.css file
app.get("/CSS/universal-main", (req, res) => {
  res.sendFile(path.join(__dirname, "CSS/main.css"));
});

// the following edits until end comment is changes or additions made by Alby

app.get("/CSS/about-card", (req, res) => {
  res.sendFile(path.join(__dirname, "CSS/webHome.css/about-card.css"));
});

app.get("/CSS/filler-card", (req, res) => {
  res.sendFile(path.join(__dirname, "CSS/webHome.css/filler-card.css"));
});

app.get("/CSS/step-cards", (req, res) => {
  res.sendFile(path.join(__dirname, "CSS/webHome.css/step-cards.css"));
});

app.get("/CSS/action", (req, res) => {
  res.sendFile(path.join(__dirname, "CSS/webHome.css/action.css"));
});

app.get("/CSS/cards", (req, res) => {
  res.sendFile(path.join(__dirname, "CSS/webHome.css/cards.css"));
});

app.get("/CSS/sign", (req, res) => {
  res.sendFile(path.join(__dirname, "CSS/sign.css"));
});

app.get("/CSS/viewer", (req, res) => {
  res.sendFile(path.join(__dirname, "CSS/userHomepage.css/viewer.css"));
});

app.get("/CSS/editor", (req, res) => {
  res.sendFile(path.join(__dirname, "CSS/userHomepage.css/editor.css"));
});

//end comment, for now

// The logo
app.get("/assets/logo", (req, res) => {
  res.sendFile(path.join(__dirname, "assets/portl.png"));
});

// search.png
app.get("/assets/search", (req, res) => {
  res.sendFile(path.join(__dirname, "assets/search.png"));
});

// house-building.png
app.get("/assets/house-building", (req, res) => {
  res.sendFile(path.join(__dirname, "assets/house-building.png"));
});

// paint-brush.png
app.get("/assets/paint-brush", (req, res) => {
  res.sendFile(path.join(__dirname, "assets/paint-brush.png"));
});

// file-upload.png
app.get("/assets/file-upload", (req, res) => {
  res.sendFile(path.join(__dirname, "assets/file-upload.png"));
});

// cross.png
app.get("/assets/cross", (req, res) => {
  res.sendFile(path.join(__dirname, "assets/cross.png"));
});

// edit.png
app.get("/assets/edit", (req, res) => {
  res.sendFile(path.join(__dirname, "assets/edit.png"));
});

// settings.png
app.get("/assets/settings", (req, res) => {
  res.sendFile(path.join(__dirname, "assets/settings.png"));
});

// step-type.png
app.get("/assets/step-type", (req, res) => {
  res.sendFile(path.join(__dirname, "assets/step-type.png"));
});

// step-view.png
app.get("/assets/step-view", (req, res) => {
  res.sendFile(path.join(__dirname, "assets/step-view.png"));
});

// step-post.png
app.get("/assets/step-post", (req, res) => {
  res.sendFile(path.join(__dirname, "assets/step-post.png"));
});

// Admin page
app.get("/admin", (req, res) => {
  res.sendFile(path.join(__dirname, "HTML/admin.html"));
});

// Hompeage - HTML
app.get("/", function (req, res) {
  res.sendFile(path.join(__dirname, "HTML/webHome.html"));
});

// Hub
app.get("/hub", function (req, res) {
  res.sendFile(path.join(__dirname, "HTML/hub.html"));
});
app.get("/javascript/hub", function (req, res) {
  res.sendFile(path.join(__dirname, "JS/hub.js"));
});
app.get("/CSS/hub", function (req, res) {
  res.sendFile(path.join(__dirname, "CSS/hub.css"));
});

// User hompage
app.get("/@:user", function (req, res) {
  res.sendFile(path.join(__dirname, "HTML/userHomepage.html"));
});
app.post("/data/portDetails/:name", function (req, res) {
  let user = req.params["name"];
  console.log(user + "'s userHomepage was opened");

  db.all("SELECT username FROM ports", function (err, data) {
    if (err) {
      console.log(err);
    } else {
      let errHandler = true;

      for (let i = 0; i < data.length; i++) {
        if (user == data[i].username) {
          res.send("Go");
          errHandler = false;
        }
      }

      if (errHandler) {
        res.send("No go");
      }
    }
  });
});

app.get("/CSS/userHomepage", (req, res) => {
  res.sendFile(path.join(__dirname, "CSS/userHomepage.css"));
});
app.get("/javascript/userHomepage", (req, res) => {
  res.sendFile(path.join(__dirname, "JS/userHomepage.js"));
});
app.get("/signup", (req, res) => {
  res.sendFile(path.join(__dirname, "HTML/signUp.html"));
});
app.get("/javascript/signup", (req, res) => {
  res.sendFile(path.join(__dirname, "JS/signUp.js"));
});
app.get("/javascript/webHome", (req, res) => {
  res.sendFile(path.join(__dirname, "JS/webHome.js"));
});
app.get("/login", (req, res) => {
  res.sendFile(path.join(__dirname, "HTML/logIn.html"));
});
app.get("/javascript/login", (req, res) => {
  res.sendFile(path.join(__dirname, "JS/login.js"));
});
app.get("/settings", (req, res) => {
  res.sendFile(path.join(__dirname, "HTML/settings.html"));
});

app.get("/javascript/settings", (req, res) => {
  res.sendFile(path.join(__dirname, "JS/settings.js"));
});

// Running the server
app.listen(port, () => {
  console.log(`Server is running on port: ${port}`);
});

/*-------------------------------------------Hussain's code---------------------------------------------
 
function adminPageSecurity(){
  if(window.location.href == "https://fd4a3a12-c5ec-46e6-921a-25715493e108-00-3apc00536hspk.worf.replit.dev/admin") {
    let loggedInUser = localStorage.getItem("username");
    let admins = ["adityaUsername", "albyUsername", "hussainUsername"];
    for(let i=0; i<admins.length; i++){
      if(loggedInUser != admins[i]){
        window.location.assign(window.location.origin);
      }
    }
  }
}
*/
